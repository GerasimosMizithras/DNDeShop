// Function to set theme
function setTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

// Function to toggle theme
function toggleTheme() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    updateButtonIcon();
}

// Update the theme toggle button icon
function updateButtonIcon() {
    const currentTheme = localStorage.getItem('theme') || 'light';
    const button = document.querySelector('#themeToggle');
    if (button) {
        button.innerHTML = currentTheme === 'light'
            ? '<i class="fas fa-moon"></i>'
            : '<i class="fas fa-sun"></i>';
    }
}

// Initialize theme and event listeners
window.addEventListener('DOMContentLoaded', () => {
    // Set theme from localStorage or default to light
    const savedTheme = localStorage.getItem('theme') || 'light';
    setTheme(savedTheme);
    updateButtonIcon();

    // Add click event to the navbar theme toggle button
    const button = document.querySelector('#themeToggle');
    if (button) {
        button.addEventListener('click', toggleTheme);
    }

    // Update icon when theme changes (for programmatic changes)
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'data-theme') {
                updateButtonIcon();
            }
        });
    });
    observer.observe(document.documentElement, {
        attributes: true,
        attributeFilter: ['data-theme']
    });
}); 