from django.contrib import admin
from .models import CartItem

@admin.register(CartItem)
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('user', 'item', 'quantity', 'total_price_display', 'created_at')
    list_filter = ('created_at', 'item__category', 'item__rarity')
    search_fields = ('user__username', 'item__name')
    raw_id_fields = ('user', 'item')
    readonly_fields = ('created_at', 'updated_at', 'total_price')
    list_per_page = 20

    def total_price_display(self, obj):
        return f"${obj.total_price:.2f}"
    total_price_display.short_description = 'Total Price'

    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'item')
