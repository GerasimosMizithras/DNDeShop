from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from market.models import Item
from .models import CartItem
from django.http import JsonResponse
from accounts.models import Profile, GoldTransaction
from django.contrib.auth.models import User

# Create your views here.

@login_required
def view_cart(request):
    cart_items = CartItem.objects.filter(user=request.user).select_related('item')
    total = sum(item.item.price * item.quantity for item in cart_items)
    
    context = {
        'cart_items': cart_items,
        'total': total,
    }
    return render(request, 'cart/cart.html', context)

@login_required
def add_to_cart(request, item_id):
    item = get_object_or_404(Item, id=item_id)
    cart_item, created = CartItem.objects.get_or_create(
        user=request.user,
        item=item,
        defaults={'quantity': 1}
    )
    
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    
    messages.success(request, f'{item.name} added to cart.')
    return redirect('market:item_detail', item_id=item_id)

@login_required
def remove_from_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, user=request.user, item_id=item_id)
    cart_item.delete()
    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({'success': True})
    messages.success(request, 'Item removed from cart.')
    return redirect('cart:view_cart')

@login_required
def update_cart(request, item_id):
    if request.method == 'POST':
        quantity = int(request.POST.get('quantity', 1))
        cart_item = get_object_or_404(CartItem, user=request.user, item_id=item_id)
        
        if quantity > 0:
            cart_item.quantity = quantity
            cart_item.save()
        else:
            cart_item.delete()
            
    return redirect('cart:view_cart')

@login_required
def checkout(request):
    cart_items = CartItem.objects.filter(user=request.user)
    total = sum(item.item.price * item.quantity for item in cart_items)
    profile, _ = Profile.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        if profile.balance < total:
            messages.error(request, f"You do not have enough gold (GP) to complete this purchase. You need {total} GP, but only have {profile.balance} GP.")
            return redirect('cart:checkout')
        # Deduct gold
        profile.balance -= total
        profile.save()
        # Log the purchase as a GoldTransaction (from Player to store)
        GoldTransaction.objects.create(
            from_user=request.user,
            to_user=None,
            amount=-total,
            note='Purchase from store'
        )
        # Clear the cart
        cart_items.delete()
        messages.success(request, f"Purchase successful! {total} GP has been deducted from your balance.")
        return redirect('market:search_items')

    context = {
        'cart_items': cart_items,
        'total': total,
    }
    return render(request, 'cart/checkout.html', context)
