from django.shortcuts import render
from django.core.mail import send_mail
from django.contrib import messages
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect

def custom_404(request, exception):
    return render(request, 'core/404.html', status=404)

def custom_403(request, exception):
    return render(request, 'core/403.html', status=403)

@csrf_exempt
def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        if name and email and subject and message:
            full_message = f"From: {name} <{email}>\n\n{message}"
            send_mail(
                f"[D&D Fantasy Store] {subject}",
                full_message,
                settings.DEFAULT_FROM_EMAIL,
                [settings.CONTACT_EMAIL],
                fail_silently=False,
            )
            messages.success(request, 'Your message has been sent by arcane raven! The Guildmaster will respond soon.')
            return redirect('contact')
        else:
            messages.error(request, 'All fields are required to summon the Guildmaster.')
    return render(request, 'contact.html') 