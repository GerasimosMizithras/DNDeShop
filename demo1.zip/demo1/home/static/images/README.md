# Required Images for D&D Fantasy Store

The following images need to be added to make the store's frontend work properly. You can get these images from D&D 5E or Baldur's Gate 3 wikis, ensuring you have the right to use them.

## Categories Directory (`/categories/`)

1. `flametongue-sword.jpg` - A flaming sword image
2. `elven-chain.jpg` - Elven chain mail armor
3. `greater-healing-potion.jpg` - Red healing potion

## Items Directory (`/items/`)

1. `flametongue-sword-detail.jpg` - Detailed view of the flaming sword
2. `elven-chain-detail.jpg` - Detailed view of the elven chain mail
3. `greater-healing-potion-detail.jpg` - Detailed view of the healing potion
4. `ring-of-protection.jpg` - Ring of Protection image

## Image Requirements

- All images should be high quality (minimum 800x600 pixels)
- Images should have a transparent or dark background to match the theme
- Category images can be more general/iconic
- Item detail images should show the specific item clearly

## Suggested Sources

1. Baldur's Gate 3 Wiki: https://baldursgate3.wiki.fextralife.com/
2. D&D 5E Wiki: https://www.dndbeyond.com/magic-items
3. Official D&D artwork (with proper licensing)

Please ensure all images comply with copyright and usage rights before adding them to the project. 