// Hero Background
const heroCtx = document.querySelector('#heroCanvas').getContext('2d');
heroCtx.fillStyle = '#2c3e50';
heroCtx.fillRect(0, 0, 1200, 600);
for(let i = 0; i < 50; i++) {
    heroCtx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.5})`;
    heroCtx.beginPath();
    heroCtx.arc(Math.random() * 1200, Math.random() * 600, Math.random() * 3, 0, Math.PI * 2);
    heroCtx.fill();
}

// Category Default
const catCtx = document.querySelector('#categoryCanvas').getContext('2d');
catCtx.fillStyle = '#3498db';
catCtx.fillRect(0, 0, 800, 600);
catCtx.fillStyle = '#fff';
catCtx.font = '48px Arial';
catCtx.textAlign = 'center';
catCtx.fillText('Category Image', 400, 300);

// Product Default
const prodCtx = document.querySelector('#productCanvas').getContext('2d');
prodCtx.fillStyle = '#e74c3c';
prodCtx.fillRect(0, 0, 600, 800);
prodCtx.fillStyle = '#fff';
prodCtx.font = '36px Arial';
prodCtx.textAlign = 'center';
prodCtx.fillText('Product Image', 300, 400); 