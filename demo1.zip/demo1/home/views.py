from django.shortcuts import render
from market.models import Category, Item
import random

def home(request):
    """
    Landing page view showing featured categories and products.
    """
    categories = Category.objects.all()
    all_items = list(Item.objects.all())
    featured_items = random.sample(all_items, min(4, len(all_items))) if all_items else []

    context = {
        'categories': categories,
        'featured_items': featured_items,
    }
    return render(request, 'home/index.html', context)
