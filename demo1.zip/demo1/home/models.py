from django.db import models

# Home app specific models can be added here if needed in the future
