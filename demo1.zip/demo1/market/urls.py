from django.urls import path
from . import views

app_name = 'market'

urlpatterns = [
    path('', views.category_list, name='category_list'),
    path('search/', views.search_items, name='search_items'),
    path('item/<int:item_id>/', views.item_detail, name='item_detail'),
    path('item/<int:item_id>/review/', views.submit_review, name='submit_review'),
    path('category/<int:category_id>/', views.category_items, name='category_items'),
] 