from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Avg

class Category(models.Model):
    name = models.CharField(max_length=50)
    description = models.TextField()
    image = models.ImageField(upload_to='category_images/')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name_plural = "Categories"
        ordering = ['name']

class Item(models.Model):
    RARITY_CHOICES = [
        ('common', 'Common'),
        ('uncommon', 'Uncommon'),
        ('rare', 'Rare'),
        ('very_rare', 'Very Rare'),
        ('legendary', 'Legendary'),
        ('artifact', 'Artifact'),
    ]
    
    ITEM_TYPES = [
        ('weapon', 'Weapon'),
        ('armor', 'Armor'),
        ('potion', 'Potion'),
        ('ring', 'Ring'),
        ('rod', 'Rod'),
        ('scroll', 'Scroll'),
        ('staff', 'Staff'),
        ('wand', 'Wand'),
        ('wonderous', 'Wonderous Item'),
    ]

    name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    rarity = models.CharField(max_length=20, choices=RARITY_CHOICES)
    item_type = models.CharField(max_length=20, choices=ITEM_TYPES)
    requires_attunement = models.BooleanField(default=False)
    weight = models.DecimalField(max_digits=5, decimal_places=2, help_text="Weight in pounds")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name='items')
    image = models.ImageField(upload_to='item_images/', null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    @property
    def average_rating(self):
        return self.reviews.aggregate(Avg('rating'))['rating__avg'] or 0

    def get_similar_items(self, limit=3):
        """Get similar items based on category and rarity"""
        return Item.objects.filter(
            models.Q(category=self.category) | models.Q(rarity=self.rarity)
        ).exclude(id=self.id)[:limit]

    class Meta:
        ordering = ['name']

class Review(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='reviews')
    rating = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text="Rating from 1 to 5 stars"
    )
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Review by {self.user.username} for {self.item.name}"

    class Meta:
        unique_together = ('user', 'item')
        ordering = ['-created_at']
