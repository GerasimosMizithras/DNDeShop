document.addEventListener('DOMContentLoaded', function() {
    // Search form handling
    const searchForm = document.querySelector('#searchForm');
    const searchInput = document.querySelector('#searchInput');
    const filterForm = document.querySelector('#filterForm');
    const sortSelect = document.querySelector('#sortSelect');
    const priceRange = document.querySelector('#priceRange');
    const priceValue = document.querySelector('#priceValue');

    // Update price value display
    if (priceRange) {
        priceRange.addEventListener('input', function() {
            priceValue.textContent = `${priceRange.value} GP`;
        });
    }

    // Handle filter form submission
    if (filterForm) {
        filterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const formData = new FormData(filterForm);
            const params = new URLSearchParams(formData);
            window.location.href = `${window.location.pathname}?${params.toString()}`;
        });
    }

    // Handle sort selection
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            filterForm.submit();
        });
    }

    // Add animation classes to product cards
    const productCards = document.querySelectorAll('.product-card');
    productCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
    });
}); 