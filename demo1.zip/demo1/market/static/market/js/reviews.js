document.addEventListener('DOMContentLoaded', function() {
    const reviewForm = document.querySelector('#review-form');
    if (!reviewForm) return;

    reviewForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(reviewForm);
        const itemId = reviewForm.dataset.itemId;
        const url = `/store/items/${itemId}/review/`;
        
        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': getCookie('csrftoken')
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update average rating display
                document.querySelector('#avg-rating').textContent = data.new_avg.toFixed(1);
                
                // Show success message
                const message = document.createElement('div');
                message.className = 'alert alert-success';
                message.textContent = data.message;
                reviewForm.insertAdjacentElement('beforebegin', message);
                
                // Clear form
                reviewForm.reset();
                
                // Remove message after 3 seconds
                setTimeout(() => message.remove(), 3000);
            } else {
                throw new Error(data.message);
            }
        })
        .catch(error => {
            const message = document.createElement('div');
            message.className = 'alert alert-danger';
            message.textContent = error.message || 'An error occurred. Please try again.';
            reviewForm.insertAdjacentElement('beforebegin', message);
            setTimeout(() => message.remove(), 3000);
        });
    });
});

// Helper function to get CSRF token from cookies
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
} 