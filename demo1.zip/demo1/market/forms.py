from django import forms
from .models import Category, Item

class ItemSearchForm(forms.Form):
    RARITY_CHOICES = Item.RARITY_CHOICES
    ITEM_TYPES = Item.ITEM_TYPES

    query = forms.CharField(
        required=False,
        min_length=2,
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Search for magical items...'
        })
    )
    
    category = forms.ModelChoiceField(
        queryset=Category.objects.all(),
        required=False,
        empty_label="All Categories",
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    
    rarity = forms.ChoiceField(
        choices=[('', 'All Rarities')] + list(RARITY_CHOICES),
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    
    item_type = forms.ChoiceField(
        choices=[('', 'All Types')] + list(ITEM_TYPES),
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    
    requires_attunement = forms.ChoiceField(
        choices=[
            ('', 'Any'),
            ('true', 'Requires Attunement'),
            ('false', 'No Attunement Required')
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    )
    
    min_price = forms.DecimalField(
        required=False,
        min_value=0,
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Min Price (GP)'
        })
    )
    
    max_price = forms.DecimalField(
        required=False,
        min_value=0,
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Max Price (GP)'
        })
    )
    
    sort_by = forms.ChoiceField(
        choices=[
            ('name', 'Name (A-Z)'),
            ('-name', 'Name (Z-A)'),
            ('price', 'Price (Low to High)'),
            ('-price', 'Price (High to Low)'),
            ('-created_at', 'Newest First'),
            ('rarity', 'Rarity (Common to Legendary)'),
            ('-rarity', 'Rarity (Legendary to Common)'),
            ('item_type', 'Item Type'),
            ('weight', 'Weight (Light to Heavy)'),
            ('-weight', 'Weight (Heavy to Light)'),
        ],
        required=False,
        widget=forms.Select(attrs={
            'class': 'form-select'
        })
    ) 