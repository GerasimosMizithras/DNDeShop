from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Avg
from .models import Item, Category, Review
from django.http import JsonResponse
from django.core.paginator import Paginator
from .forms import ItemSearchForm
import difflib

def category_list(request):
    """Display all available categories"""
    categories = Category.objects.all().order_by('name')
    
    # Get item count and average price for each category
    for category in categories:
        category.item_count = category.items.count()
        category.avg_price = category.items.aggregate(Avg('price'))['price__avg']
    
    context = {
        'categories': categories,
    }
    
    return render(request, 'market/category_list.html', context)

def search_items(request):
    """Search and filter items with advanced options"""
    q = request.GET.get('q', '')
    items = Item.objects.all()

    if q:
        items = items.filter(
            Q(name__icontains=q) |
            Q(description__icontains=q)
        )
        # Annotate similarity score using difflib
        items = list(items)
        def similarity(item):
            return difflib.SequenceMatcher(None, q.lower(), item.name.lower()).ratio()
        items.sort(key=lambda item: -similarity(item))

    # Category filter
    category_id = request.GET.get('category')
    categories = Category.objects.all()
    if category_id:
        items = [item for item in items if item.category_id == int(category_id)]

    # Rarity filter
    rarity = request.GET.get('rarity')
    rarities = Item.RARITY_CHOICES
    if rarity:
        items = [item for item in items if item.rarity == rarity]

    # Max price filter
    max_price = request.GET.get('max_price')
    if max_price:
        try:
            items = [item for item in items if item.price <= float(max_price)]
        except ValueError:
            pass

    # Pagination
    paginator = Paginator(items, 12)
    page_number = request.GET.get('page')
    items_page = paginator.get_page(page_number)

    context = {
        'items': items_page,
        'categories': categories,
        'rarities': rarities,
        'q': q,
    }
    return render(request, 'market/search.html', context)

def category_items(request, category_id):
    """Show items in a specific category"""
    category = get_object_or_404(Category, pk=category_id)
    items = category.items.all()
    
    # Handle rarity filter
    rarity = request.GET.get('rarity')
    if rarity:
        items = items.filter(rarity=rarity)
    
    # Handle item type filter
    item_type = request.GET.get('item_type')
    if item_type:
        items = items.filter(item_type=item_type)
    
    # Handle sorting
    sort_by = request.GET.get('sort')
    if sort_by:
        items = items.order_by(sort_by)
    
    context = {
        'category': category,
        'items': items,
        'rarities': Item.RARITY_CHOICES,
        'item_types': Item.ITEM_TYPES,
        'selected_rarity': rarity,
        'selected_type': item_type,
        'selected_sort': sort_by,
    }
    
    return render(request, 'market/category_items.html', context)

def item_detail(request, item_id):
    """Show detailed item information and reviews"""
    item = get_object_or_404(Item, pk=item_id)
    reviews = item.reviews.all().select_related('user')
    similar_items = item.get_similar_items()
    
    context = {
        'item': item,
        'reviews': reviews,
        'similar_items': similar_items,
        'avg_rating': item.average_rating,
    }
    
    return render(request, 'market/item_detail.html', context)

@login_required
def submit_review(request, item_id):
    """Submit or update a review for an item"""
    item = get_object_or_404(Item, pk=item_id)
    
    if request.method == 'POST':
        rating = request.POST.get('rating')
        comment = request.POST.get('comment')
        
        if rating and comment:
            review, created = Review.objects.get_or_create(
                user=request.user,
                item=item,
                defaults={'rating': rating, 'comment': comment}
            )
            
            if not created:
                review.rating = rating
                review.comment = comment
                review.save()
            
            return JsonResponse({
                'status': 'success',
                'message': 'Your magical review has been inscribed!'
            })
    
    return JsonResponse({
        'status': 'error',
        'message': 'The ancient magic rejects your incomplete spell. Please provide both rating and comment.'
    })
