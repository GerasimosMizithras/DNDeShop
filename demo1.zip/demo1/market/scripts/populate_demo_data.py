import os
import random
from django.core.files.images import ImageFile
from market.models import Category, Item, Review
from django.conf import settings
from django.contrib.auth.models import User

# Path to the images directory
images_dir = os.path.join(settings.BASE_DIR, 'market', 'static', 'market', 'images')

RARITIES = ['common', 'uncommon', 'rare', 'very_rare', 'legendary', 'artifact']
ITEM_TYPES = ['weapon', 'armor', 'potion', 'ring', 'rod', 'scroll', 'staff', 'wand', 'wonderous']

# Ensure at least one demo user exists for reviews
demo_user, _ = User.objects.get_or_create(username='demouser', defaults={'email': 'demo@example.com'})

# --- CATEGORY RENAMING AND DESCRIPTION MAPPING ---
CATEGORY_RENAMES = {
    'Demo Category': ('All items', 'All magical items in the market.'),
    'Elven': ('Armor', 'Protective gear and magical armor.'),
    'Final': ('Swords', 'Blades and magical swords.'),
    'Fire': ('Consumable', 'Potions, food, and single-use magical items.'),
    'Healing': ('Scrolls/Spells', 'Magical scrolls and spell items.'),
    'Ice': ('Miscellaneous', 'Other magical items and curiosities.'),
}

from django.db import transaction

def update_categories():
    from market.models import Category
    CATEGORY_RENAMES = {
        'Demo Category': ('All items', 'All magical items in the market.'),
        'Elven': ('Armor', 'Protective gear and magical armor.'),
        'Final': ('Swords', 'Blades and magical swords.'),
        'Fire': ('Consumable', 'Potions, food, and single-use magical items.'),
        'Healing': ('Scrolls/Spells', 'Magical scrolls and spell items.'),
        'Ice': ('Miscellaneous', 'Other magical items and curiosities.'),
    }
    for old_name, (new_name, new_desc) in CATEGORY_RENAMES.items():
        try:
            cat = Category.objects.get(name=old_name)
            cat.name = new_name
            cat.description = new_desc
            cat.save()
            print(f"Updated category '{old_name}' to '{new_name}'")
        except Category.DoesNotExist:
            print(f"Category '{old_name}' not found, skipping.")

def random_comment():
    return random.choice([
        'A truly magical item!',
        'Works as expected, would recommend.',
        'Not as powerful as I hoped.',
        'Legendary quality!',
        'Perfect for my next quest.',
        'A bit overpriced, but useful.',
        'The magic is strong with this one.',
        'My party loved it!',
        'Would buy again.',
        'A must-have for adventurers.'
    ])

for idx, filename in enumerate(os.listdir(images_dir)):
    if not filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
        continue
    name = os.path.splitext(filename)[0].replace('_', ' ').replace('-', ' ').title()
    description = f"A magical item called {name}. Its powers are mysterious and arbitrary."
    price = 100 + idx * 50
    rarity = RARITIES[idx % len(RARITIES)]
    item_type = ITEM_TYPES[idx % len(ITEM_TYPES)]
    weight = 1.0 + idx
    image_path = os.path.join(images_dir, filename)
    # Use the first word of the item name as the category, or create a default
    category_name = name.split()[0]
    category, _ = Category.objects.get_or_create(
        name=category_name,
        defaults={
            'description': f'Items related to {category_name}',
            'image': ''
        }
    )
    with open(image_path, 'rb') as img_file:
        item, created = Item.objects.get_or_create(
            name=name,
            defaults={
                'description': description,
                'price': price,
                'rarity': rarity,
                'item_type': item_type,
                'requires_attunement': False,
                'weight': weight,
                'category': category,
            }
        )
        if created:
            item.image.save(filename, ImageFile(img_file), save=True)
    # Add a random review for this item
    Review.objects.get_or_create(
        user=demo_user,
        item=item,
        defaults={
            'rating': random.randint(1, 5),
            'comment': random_comment(),
        }
    )
    print(f"Created: {name} in category {category_name} with a random review") 