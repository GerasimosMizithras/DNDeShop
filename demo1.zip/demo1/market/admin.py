from django.contrib import admin
from django.utils.html import format_html
from .models import Category, Item, Review

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'description_preview', 'item_count', 'created_at', 'updated_at')
    search_fields = ('name', 'description')
    readonly_fields = ('created_at', 'updated_at')
    list_per_page = 20

    def description_preview(self, obj):
        return obj.description[:100] + '...' if len(obj.description) > 100 else obj.description
    description_preview.short_description = 'Description'

    def item_count(self, obj):
        return obj.items.count()
    item_count.short_description = 'Number of Items'

@admin.register(Item)
class ItemAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'item_type', 'rarity', 'price', 'requires_attunement', 'display_image', 'average_rating_display')
    list_filter = ('category', 'item_type', 'rarity', 'requires_attunement', 'created_at')
    search_fields = ('name', 'description')
    readonly_fields = ('created_at', 'updated_at', 'average_rating')
    fieldsets = (
        ('Basic Information', {
            'fields': ('name', 'description', 'category', 'image')
        }),
        ('Item Details', {
            'fields': ('item_type', 'rarity', 'price', 'weight', 'requires_attunement')
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at', 'average_rating'),
            'classes': ('collapse',)
        })
    )
    list_per_page = 20

    def display_image(self, obj):
        if obj.image:
            return format_html('<img src="{}" width="50" height="50" />', obj.image.url)
        return "No image"
    display_image.short_description = 'Image'

    def average_rating_display(self, obj):
        avg = obj.average_rating
        return f"{avg:.1f} ★" if avg else "No ratings"
    average_rating_display.short_description = 'Rating'

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('user', 'item', 'rating_stars', 'comment_preview', 'created_at')
    list_filter = ('rating', 'created_at', 'item__rarity', 'item__category')
    search_fields = ('comment', 'user__username', 'item__name')
    readonly_fields = ('created_at', 'updated_at')
    raw_id_fields = ('user', 'item')
    list_per_page = 20

    def rating_stars(self, obj):
        return '★' * obj.rating + '☆' * (5 - obj.rating)
    rating_stars.short_description = 'Rating'

    def comment_preview(self, obj):
        return obj.comment[:100] + '...' if len(obj.comment) > 100 else obj.comment
    comment_preview.short_description = 'Comment'
