import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'demo1.settings')
django.setup()

import market.models as market_models
from django.core.files import File

# Define categories
categories = [
    {
        'name': 'Weapons',
        'description': 'Powerful weapons imbued with magical properties',
        'image': 'Ornate_Sword.PNG',
    },
    {
        'name': 'Potions',
        'description': 'Potent magical potions for healing and enhancement',
        'image': 'healing_potion.PNG',
    },
    {
        'name': 'Wands',
        'description': 'Wands that channel arcane energy',
        'image': 'Final_Spark.PNG',
    },
    {
        'name': 'Wonderous Items',
        'description': 'Rare and unique magical items',
        'image': 'Ice.PNG',
    },
]

category_objs = {}
image_dir = os.path.join('market', 'static', 'market', 'images')
media_dir = os.path.join('media', 'category_images')
os.makedirs(media_dir, exist_ok=True)

for cat in categories:
    image_path = os.path.join(image_dir, cat['image'])
    media_path = os.path.join(media_dir, cat['image'])
    if not os.path.exists(media_path):
        with open(image_path, 'rb') as src, open(media_path, 'wb') as dst:
            dst.write(src.read())
    with open(media_path, 'rb') as img_file:
        obj, _ = market_models.Category.objects.get_or_create(
            name=cat['name'],
            defaults={
                'description': cat['description'],
                'image': File(img_file, name=cat['image'])
            }
        )
        category_objs[cat['name']] = obj

# Define magical items
items = [
    {
        'name': 'Potion of Greater Healing',
        'description': 'A sparkling red potion that restores vitality and closes wounds. Favored by adventurers for its potent healing properties.',
        'price': 150.00,
        'rarity': 'uncommon',
        'item_type': 'potion',
        'requires_attunement': False,
        'weight': 0.5,
        'category': 'Potions',
        'image': 'healing_potion.PNG',
    },
    {
        'name': 'Ornate Sword of Valor',
        'description': 'A beautifully crafted sword with intricate engravings. Said to inspire courage in its wielder and shine with a faint golden light.',
        'price': 1200.00,
        'rarity': 'rare',
        'item_type': 'weapon',
        'requires_attunement': True,
        'weight': 3.0,
        'category': 'Weapons',
        'image': 'Ornate_Sword.PNG',
    },
    {
        'name': 'Final Spark Wand',
        'description': 'This slender wand crackles with residual energy. It is rumored to unleash a powerful bolt of lightning as a last resort.',
        'price': 3500.00,
        'rarity': 'very_rare',
        'item_type': 'wand',
        'requires_attunement': True,
        'weight': 1.0,
        'category': 'Wands',
        'image': 'Final_Spark.PNG',
    },
    {
        'name': 'Arrow of Eternal Flame',
        'description': 'A single arrow with a burning tip that never extinguishes. Perfect for lighting the way or igniting foes from afar.',
        'price': 250.00,
        'rarity': 'uncommon',
        'item_type': 'weapon',
        'requires_attunement': False,
        'weight': 0.1,
        'category': 'Weapons',
        'image': 'Fire_Arrow.PNG',
    },
    {
        'name': 'Lightbringer Mace',
        'description': 'This radiant mace glows with holy light, banishing darkness and dealing extra damage to undead.',
        'price': 2000.00,
        'rarity': 'rare',
        'item_type': 'weapon',
        'requires_attunement': True,
        'weight': 4.0,
        'category': 'Weapons',
        'image': 'Lightbringer.PNG',
    },
    {
        'name': 'Shard of Eternal Ice',
        'description': 'A crystalline shard that radiates cold. Can be used as a focus for frost magic or as a chilling weapon.',
        'price': 1800.00,
        'rarity': 'rare',
        'item_type': 'wonderous',
        'requires_attunement': True,
        'weight': 0.7,
        'category': 'Wonderous Items',
        'image': 'Ice.PNG',
    },
]

item_media_dir = os.path.join('media', 'item_images')
os.makedirs(item_media_dir, exist_ok=True)

for item in items:
    image_path = os.path.join(image_dir, item['image'])
    media_path = os.path.join(item_media_dir, item['image'])
    if not os.path.exists(media_path):
        with open(image_path, 'rb') as src, open(media_path, 'wb') as dst:
            dst.write(src.read())
    with open(media_path, 'rb') as img_file:
        market_models.Item.objects.get_or_create(
            name=item['name'],
            defaults={
                'description': item['description'],
                'price': item['price'],
                'rarity': item['rarity'],
                'item_type': item['item_type'],
                'requires_attunement': item['requires_attunement'],
                'weight': item['weight'],
                'category': category_objs[item['category']],
                'image': File(img_file, name=item['image'])
            }
        )

print("Sample magical categories and items created successfully!") 