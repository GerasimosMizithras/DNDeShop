from django import forms
from market.models import Item
from django.contrib.auth.models import User
from accounts.models import Profile

class ManagerItemForm(forms.ModelForm):
    name = forms.CharField(min_length=3, max_length=100, required=True)
    description = forms.CharField(min_length=10, widget=forms.Textarea, required=True)
    price = forms.DecimalField(min_value=1, max_digits=10, decimal_places=2, required=True)
    weight = forms.DecimalField(min_value=0.1, max_digits=5, decimal_places=2, required=True)
    image = forms.ImageField(required=False)
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            # Add 'form-control' and center fields
            field.widget.attrs['class'] = field.widget.attrs.get('class', '') + ' form-control mx-auto'
            # Add required and aria-required for required fields only
            if field.required:
                field.widget.attrs['required'] = 'required'
                field.widget.attrs['aria-required'] = 'true'

    class Meta:
        model = Item
        fields = ['name', 'description', 'price', 'rarity', 'item_type', 'requires_attunement', 'weight', 'category', 'image']

class GoldCreditForm(forms.Form):
    players = forms.ModelMultipleChoiceField(queryset=User.objects.filter(groups__name='Player'), label='Players', required=True, help_text='Select up to 5 Players')
    amount = forms.DecimalField(min_value=1, max_digits=10, decimal_places=2, label='Gold Amount (GP)', required=True)
    note = forms.CharField(max_length=255, required=False, label='Note/Reason', widget=forms.TextInput(attrs={'placeholder': 'Optional reason for credit'}))

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for name, field in self.fields.items():
            field.widget.attrs['class'] = field.widget.attrs.get('class', '') + ' form-control mx-auto'
            if field.required:
                field.widget.attrs['required'] = 'required'
                field.widget.attrs['aria-required'] = 'true'
        self.fields['players'].widget.attrs['size'] = 6

    def clean_players(self):
        players = self.cleaned_data['players']
        if players.count() > 5:
            raise forms.ValidationError('You can select up to 5 Players at a time.')
        return players 