from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required, user_passes_test
from market.models import Item, Category
from .forms import ManagerItemForm, GoldCreditForm
from accounts.models import Profile, GoldTransaction
from django.contrib import messages
from django.contrib.auth.models import User


def is_manager(user):
    return user.is_authenticated and (user.groups.filter(name='Manager').exists() or user.is_superuser)

@login_required
@user_passes_test(is_manager)
def dashboard(request):
    return render(request, 'manager/dashboard.html')

@login_required
@user_passes_test(is_manager)
def list_items(request):
    items = Item.objects.all().select_related('category')
    if request.method == 'POST':
        form = ManagerItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('manager:list_items')
    else:
        form = ManagerItemForm()
    return render(request, 'manager/item_list.html', {'items': items, 'form': form})

@login_required
@user_passes_test(is_manager)
def add_item(request):
    if request.method == 'POST':
        form = ManagerItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('manager:list_items')
    else:
        form = ManagerItemForm()
    return render(request, 'manager/item_form.html', {'form': form, 'action': 'Add'})

@login_required
@user_passes_test(is_manager)
def edit_item(request, item_id):
    item = get_object_or_404(Item, pk=item_id)
    if request.method == 'POST':
        form = ManagerItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect('manager:list_items')
    else:
        form = ManagerItemForm(instance=item)
    return render(request, 'manager/item_form.html', {'form': form, 'action': 'Edit'})

@login_required
@user_passes_test(is_manager)
def delete_item(request, item_id):
    item = get_object_or_404(Item, pk=item_id)
    if request.method == 'POST':
        item.delete()
        return redirect('manager:list_items')
    return render(request, 'manager/item_confirm_delete.html', {'item': item})

@login_required
@user_passes_test(is_manager)
def credit_gold(request):
    if request.method == 'POST':
        form = GoldCreditForm(request.POST)
        if form.is_valid():
            players = form.cleaned_data['players']
            amount = form.cleaned_data['amount']
            note = form.cleaned_data['note']
            credited = []
            for player in players:
                profile, _ = Profile.objects.get_or_create(user=player)
                profile.balance += amount
                profile.save()
                GoldTransaction.objects.create(
                    from_user=request.user,
                    to_user=player,
                    amount=amount,
                    note=note or ''
                )
                credited.append(player.username)
            messages.success(request, f"Credited {amount} GP to: {', '.join(credited)}.")
            return redirect('manager:dashboard')
    else:
        form = GoldCreditForm()
    return render(request, 'manager/credit_gold.html', {'form': form})

@login_required
@user_passes_test(is_manager)
def view_orders(request):
    # Show all store purchases (to_user=None)
    orders = GoldTransaction.objects.filter(to_user=None).order_by('-timestamp')
    return render(request, 'manager/view_orders.html', {'orders': orders})

@login_required
@user_passes_test(is_manager)
def view_users(request):
    users = User.objects.all().select_related('profile')
    return render(request, 'manager/view_users.html', {'users': users})