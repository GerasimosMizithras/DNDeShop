from django.urls import path
from . import views

app_name = 'manager'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('items/', views.list_items, name='list_items'),
    path('items/add/', views.add_item, name='add_item'),
    path('items/<int:item_id>/edit/', views.edit_item, name='edit_item'),
    path('items/<int:item_id>/delete/', views.delete_item, name='delete_item'),
    path('credit-gold/', views.credit_gold, name='credit_gold'),
    path('orders/', views.view_orders, name='view_orders'),
    path('users/', views.view_users, name='view_users'),
] 