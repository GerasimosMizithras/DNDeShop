from django.contrib import admin
from .models import GoldTransaction

# Register your models here.
admin.site.register(GoldTransaction)
