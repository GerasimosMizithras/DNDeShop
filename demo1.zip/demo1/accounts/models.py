from django.db import models
from django.contrib.auth.models import User
from market.models import Item

# Create your models here.

class Profile(models.Model):
    ADVENTURER_CLASSES = [
        ('fighter', 'Fighter'),
        ('wizard', 'Wizard'),
        ('rogue', 'Rogue'),
        ('cleric', 'Cleric'),
        ('ranger', 'Ranger'),
        ('paladin', 'Paladin'),
        ('barbarian', 'Barbarian'),
        ('bard', 'Bard'),
        ('druid', 'Druid'),
        ('monk', 'Monk'),
        ('sorcerer', 'Sorcerer'),
        ('warlock', 'Warlock'),
    ]

    user = models.OneToOneField(User, on_delete=models.CASCADE)
    avatar = models.ImageField(upload_to='avatars/', null=True, blank=True)
    adventurer_class = models.CharField(max_length=20, choices=ADVENTURER_CLASSES, null=True, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    balance = models.DecimalField(max_digits=10, decimal_places=2, default=0, help_text="Gold (GP) balance for the Player")

    def __str__(self):
        return f"{self.user.username}'s Profile"

class WishlistItem(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'item')
        ordering = ['-added_at']

    def __str__(self):
        return f"{self.user.username}'s wishlist - {self.item.name}"

class RecentlyViewed(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    viewed_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'item')
        ordering = ['-viewed_at']

    def __str__(self):
        return f"{self.user.username} viewed {self.item.name}"

class GoldTransaction(models.Model):
    from_user = models.ForeignKey(User, related_name='gold_given', on_delete=models.CASCADE, help_text="DM who credited gold")
    to_user = models.ForeignKey(User, related_name='gold_received', on_delete=models.CASCADE, help_text="Player who received gold", null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    timestamp = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=255, blank=True)

    def __str__(self):
        return f"{self.from_user.username} credited {self.amount} GP to {self.to_user.username} on {self.timestamp}"
