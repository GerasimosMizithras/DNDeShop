from django.core.management.base import BaseCommand
from django.contrib.auth.models import User, Group, Permission
from market.models import Item
from cart.models import CartItem
from django.contrib.contenttypes.models import ContentType

class Command(BaseCommand):
    help = 'Create a manager group with limited permissions and a sample manager user.'

    def handle(self, *args, **options):
        # Create or get the manager group
        manager_group, created = Group.objects.get_or_create(name='Manager')

        # Permissions: can change/add/delete/view Item, can view CartItem (orders)
        item_ct = ContentType.objects.get_for_model(Item)
        cartitem_ct = ContentType.objects.get_for_model(CartItem)

        perms = [
            Permission.objects.get(codename='add_item', content_type=item_ct),
            Permission.objects.get(codename='change_item', content_type=item_ct),
            Permission.objects.get(codename='delete_item', content_type=item_ct),
            Permission.objects.get(codename='view_item', content_type=item_ct),
            Permission.objects.get(codename='view_cartitem', content_type=cartitem_ct),
        ]
        manager_group.permissions.set(perms)
        manager_group.save()

        # Create a sample manager user
        username = 'manager'
        email = 'manager@example.com'
        password = 'manager1234'
        user, user_created = User.objects.get_or_create(username=username, defaults={
            'email': email,
            'is_staff': True,
            'is_superuser': False,
        })
        if user_created:
            user.set_password(password)
            user.save()
            self.stdout.write(self.style.SUCCESS(f'Created manager user: {username} / {password}'))
        else:
            self.stdout.write(self.style.WARNING(f'Manager user already exists: {username}'))

        user.groups.add(manager_group)
        self.stdout.write(self.style.SUCCESS('Manager group and user setup complete.')) 