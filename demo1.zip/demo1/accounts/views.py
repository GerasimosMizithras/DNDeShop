from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db import models
from django.db.models import Count, Avg, Sum, F
from .models import Profile, WishlistItem, RecentlyViewed, GoldTransaction
from market.models import Review
from cart.models import CartItem
from django import forms
from django.contrib.auth.password_validation import validate_password
from django.core.exceptions import ValidationError

# Create your views here.

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        
        if user is not None:
            login(request, user)
            messages.success(request, 'Welcome back!')
            return redirect('home:home')
        else:
            messages.error(request, 'Invalid username or password.')
    
    return render(request, 'accounts/login.html')

class CustomRegisterForm(forms.ModelForm):
    password1 = forms.CharField(
        label='Password',
        widget=forms.PasswordInput,
        min_length=8,
        max_length=128,
        help_text='Make it powerful - mix letters, numbers, and special characters. Password must be at least 8 characters, include one uppercase, one lowercase, one number, and one special character.'
    )
    password2 = forms.CharField(label='Confirm Password', widget=forms.PasswordInput, min_length=8, max_length=128)

    class Meta:
        model = User
        fields = ['username', 'email']

    def clean_username(self):
        username = self.cleaned_data['username']
        if not username.isalnum() and '_' not in username:
            raise ValidationError('Username must contain only letters, numbers, and underscores.')
        if len(username) < 4 or len(username) > 20:
            raise ValidationError('Username must be between 4 and 20 characters.')
        return username

    def clean_email(self):
        email = self.cleaned_data['email']
        if not email or '@' not in email:
            raise ValidationError('Enter a valid email address.')
        return email

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')
        if password1 and password2:
            if password1 != password2:
                raise ValidationError('Passwords do not match.')
            # Password strength
            if len(password1) < 8:
                raise ValidationError('Password must be at least 8 characters long.')
            import re
            if not re.search(r'[A-Z]', password1):
                raise ValidationError('Password must contain at least one uppercase letter.')
            if not re.search(r'[a-z]', password1):
                raise ValidationError('Password must contain at least one lowercase letter.')
            if not re.search(r'\d', password1):
                raise ValidationError('Password must contain at least one number.')
            if not re.search(r'[^A-Za-z0-9]', password1):
                raise ValidationError('Password must contain at least one special character.')
            try:
                validate_password(password1)
            except ValidationError as e:
                raise ValidationError(e.messages)
        return cleaned_data

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user

def register_view(request):
    if request.method == 'POST':
        form = CustomRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('home:home')
        else:
            for error in form.errors.values():
                messages.error(request, error)
    else:
        form = CustomRegisterForm()
    
    return render(request, 'accounts/register.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('home:home')

@login_required
def profile_view(request):
    profile, _ = Profile.objects.get_or_create(user=request.user)
    # Get recent gold transactions (received and spent)
    gold_transactions = GoldTransaction.objects.filter(to_user=request.user).order_by('-timestamp')[:10]
    context = {
        'profile': profile,
        'gold_transactions': gold_transactions,
    }
    return render(request, 'accounts/profile.html', context)

@login_required
def orders_view(request):
    return render(request, 'accounts/orders.html')

@login_required
def dashboard_view(request):
    # Get user's stats
    stats = {
        'total_spent': CartItem.objects.filter(user=request.user).aggregate(
            total=Sum(F('item__price') * F('quantity'))
        )['total'] or 0,
        'orders_count': CartItem.objects.filter(user=request.user).count(),
        'reviews_count': Review.objects.filter(user=request.user).count(),
        'wishlist_count': WishlistItem.objects.filter(user=request.user).count(),
    }
    
    # Get user's wishlist items
    wishlist_items = WishlistItem.objects.filter(user=request.user).select_related('item')[:3]
    
    # Get recently viewed items
    recent_views = RecentlyViewed.objects.filter(user=request.user).select_related('item')[:3]
    
    # Get latest reviews
    latest_reviews = Review.objects.filter(user=request.user).select_related('item').order_by('-created_at')[:4]
    
    context = {
        'wishlist_items': wishlist_items,
        'recent_views': recent_views,
        'latest_reviews': latest_reviews,
        **stats,
    }
    return render(request, 'accounts/dashboard.html', context)

@login_required
def edit_profile_view(request):
    profile, created = Profile.objects.get_or_create(user=request.user)
    
    if request.method == 'POST':
        # Update profile
        profile.bio = request.POST.get('bio', '')
        profile.adventurer_class = request.POST.get('adventurer_class')
        
        if request.FILES.get('avatar'):
            profile.avatar = request.FILES['avatar']
        
        profile.save()
        
        # Update user
        request.user.first_name = request.POST.get('first_name', '')
        request.user.last_name = request.POST.get('last_name', '')
        request.user.email = request.POST.get('email', '')
        request.user.save()
        
        messages.success(request, 'Profile updated successfully!')
        return redirect('accounts:profile')
    
    context = {
        'profile': profile,
    }
    return render(request, 'accounts/edit_profile.html', context)
