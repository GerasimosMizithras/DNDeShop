document.addEventListener('DOMContentLoaded', function() {
    // CSRF token setup for AJAX requests
    function getCookie(name) {
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
    const csrftoken = getCookie('csrftoken');

    // Profile image upload preview
    const imageInput = document.querySelector('#profile-image-input');
    const imagePreview = document.querySelector('#profile-image-preview');
    
    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    addSparkleEffect(imagePreview);
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Review management
    document.querySelectorAll('.delete-review').forEach(button => {
        button.addEventListener('click', async function() {
            const reviewId = this.dataset.reviewId;
            const reviewElement = document.querySelector(`#review-${reviewId}`);
            
            if (confirm('Are you sure you want to delete this review? This spell cannot be undone!')) {
                try {
                    const response = await fetch(`/accounts/review/${reviewId}/delete/`, {
                        method: 'POST',
                        headers: {
                            'X-CSRFToken': csrftoken
                        }
                    });
                    
                    if (response.ok) {
                        reviewElement.style.opacity = '0';
                        setTimeout(() => {
                            reviewElement.remove();
                            updateReviewCount();
                        }, 500);
                    } else {
                        throw new Error('Delete failed');
                    }
                } catch (error) {
                    console.error('Error deleting review:', error);
                    showErrorMessage('Failed to delete review. The ancient magic persists!');
                }
            }
        });
    });

    // Wishlist management
    document.querySelectorAll('.remove-wishlist').forEach(button => {
        button.addEventListener('click', async function() {
            const itemId = this.dataset.itemId;
            const itemElement = document.querySelector(`#wishlist-${itemId}`);
            
            try {
                const response = await fetch(`/accounts/wishlist/${itemId}/remove/`, {
                    method: 'POST',
                    headers: {
                        'X-CSRFToken': csrftoken
                    }
                });
                
                if (response.ok) {
                    itemElement.style.opacity = '0';
                    setTimeout(() => {
                        itemElement.remove();
                        updateWishlistCount();
                    }, 500);
                } else {
                    throw new Error('Remove failed');
                }
            } catch (error) {
                console.error('Error removing from wishlist:', error);
                showErrorMessage('Failed to remove item from wishlist. The item resists!');
            }
        });
    });

    // Visual effects
    function addSparkleEffect(element) {
        const sparkle = document.createElement('div');
        sparkle.className = 'sparkle';
        element.appendChild(sparkle);
        setTimeout(() => sparkle.remove(), 1000);
    }

    function showErrorMessage(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'alert alert-danger fade-in';
        errorDiv.textContent = message;
        document.querySelector('.profile-container').prepend(errorDiv);
        setTimeout(() => {
            errorDiv.style.opacity = '0';
            setTimeout(() => errorDiv.remove(), 500);
        }, 3000);
    }

    function updateReviewCount() {
        const count = document.querySelectorAll('.review-item').length;
        document.querySelector('#review-count').textContent = count;
    }

    function updateWishlistCount() {
        const count = document.querySelectorAll('.wishlist-item').length;
        document.querySelector('#wishlist-count').textContent = count;
    }

    // Achievement animations
    document.querySelectorAll('.achievement').forEach(achievement => {
        achievement.addEventListener('mouseenter', function() {
            this.classList.add('achievement-hover');
            addSparkleEffect(this);
        });
        
        achievement.addEventListener('mouseleave', function() {
            this.classList.remove('achievement-hover');
        });
    });
}); 